/*
This software is provided for student assignment use in the Department of
Electrical and Computer Engineering, Brigham Young University, Utah, USA.
Users agree to not re-host, or redistribute the software, in source or binary
form, to other persons or other institutions. Users may modify and use the
source code for personal or educational use.
For questions, contact Brad Hutchings or Jeff Goeders, https://ece.byu.edu/
*/

#include "mio.h"
#include "utils.h"
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>

#include "hitLedTimer.h"

#define TIMER_DELAY 300
#define HITLEDTIMER_HIGH_VALUE 1
#define HITLEDTIMER_LOW_VALUE 0
#define HITLEDTIMER_OUTPUT_PIN 11

#define INIT_ST_MSG "Init state\n"
#define WAIT_ST_MSG "Wait state\n"
#define LIT_ST_MSG "Lit state\n"
#define ERROR_MSG "LED Timer Error occurred\n"

// Provides an led timer with adjustable frequency and adjustable on/off times.
// All time-based numbers are expressed in milliseconds.
// Minimum period is 1 millisecond.

// Controls both hitLed and JF-10. Make sure to disable the hitLedTimer when
// using this timer.
#define HITLED_TIMER_LED_PIN 15 // This is the MIO pin number.
#define HITLED_CYCLES 50000     // half a second

static bool debugPrint;
volatile static bool timerStartFlag = false;
uint32_t static cycleCounter;
enum hitLedTimer_st_t { init_st, wait_st, lit_st } hitLed_currentState;

// Initialize the ledTimer before you use it.
void hitLedTimer_init() {
  mio_init(false);
  hitLed_currentState = init_st;
  cycleCounter = 0;
  mio_setPinAsOutput(HITLEDTIMER_OUTPUT_PIN);
}

// debug print for the ledTimer
void hitLedTimer_debugStatePrint() {
  static enum hitLedTimer_st_t previousState;
  static bool firstPass = true;
  // Only print the message if:
  // 1. This the first pass and the value for previousState is unknown.
  // 2. previousState != led_currentState - this prevents reprinting the same
  // state name over and over.
  if (previousState != hitLed_currentState || firstPass) {
    firstPass = false; // previousState will be defined, firstPass is false.
    previousState =
        hitLed_currentState; // keep track of the last state that you were in.
    switch (hitLed_currentState) { // This prints messages based upon the state
                                   // that you were in.
    case init_st:
      printf(INIT_ST_MSG);
      break;
    case wait_st:
      printf(WAIT_ST_MSG);
      break;
    case lit_st:
      printf(LIT_ST_MSG);
      break;
    }
  }
}

// Starts the ledTimer running.
void hitLedTimer_start() { timerStartFlag = true; }

// Returns true if the timer is currently running, false otherwise.
bool hitLedTimer_running() { return timerStartFlag; }

// Terminates operation of the ledTimer.
void hitLedTimer_stop() { timerStartFlag = false; }

// Standard state-machine tick function. Call this to advance the state machine.
void hitLedTimer_tick() {
  // transitions for the ledTimer
  switch (hitLed_currentState) {
  case init_st:
    hitLed_currentState = wait_st;
    break;
  case wait_st:
    // timer start flag
    if (timerStartFlag) {
      cycleCounter = 0;
      hitLed_currentState = lit_st;
      mio_writePin(HITLEDTIMER_OUTPUT_PIN,
                   HITLEDTIMER_HIGH_VALUE); // Write a '1' to JF-1.
    } else {
      hitLed_currentState = wait_st;
    }
    break;
  case lit_st:
    // if the cycleCounter is higher than the max, then set to low
    if (cycleCounter > HITLED_CYCLES) {
      cycleCounter = 0;
      timerStartFlag = false;
      hitLed_currentState = wait_st;
      mio_writePin(HITLEDTIMER_OUTPUT_PIN,
                   HITLEDTIMER_LOW_VALUE); // Write a '1' to JF-1.
    } else {
      hitLed_currentState = lit_st;
    }
    break;
  default:
    printf(ERROR_MSG);
    printf("Current state in LED: %d\n", hitLed_currentState);
    // print an error message here.
    break;
  }

  // Perform state action next.
  switch (hitLed_currentState) {
  case init_st:
    break;
  case wait_st:
    break;
  case lit_st:
    cycleCounter++;
    break;
  default:
    printf(ERROR_MSG);
    // print an error message here.
    break;
  }

  // debug print statements
  if (debugPrint)
    hitLedTimer_debugStatePrint();
}

// Standard test function.
void hitLedTimer_runTest() {

  // continuous loop for the run test
  while (true) {
    hitLedTimer_start();
    while (hitLedTimer_running()) {
    }
    utils_msDelay(TIMER_DELAY);
  }
}

// Turns the gun's hit-LED on.
void hitLedTimer_turnLedOn() {
  mio_writePin(HITLEDTIMER_OUTPUT_PIN,
               HITLEDTIMER_HIGH_VALUE); // Write a '1' to JF-1.
}

// Turns the gun's hit-LED off.
void hitLedTimer_turnLedOff() {
  mio_writePin(HITLEDTIMER_OUTPUT_PIN,
               HITLEDTIMER_LOW_VALUE); // Write a '0' to JF-1.
}

// Disables the hitLedTimer.
void hitLedTimer_disable() { timerStartFlag = false; }

// Enables the hitLedTimer.
void hitLedTimer_enable() { timerStartFlag = true; }
